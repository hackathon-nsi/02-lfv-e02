
function supr() {
	document.getElementById("input").style.color = "black";
	document.getElementById("input").innerHTML=" ";
}
function fonction_trad(){
	document.getElementById("output").style.color = "black";
	document.getElementById("output").innerHTML="bonjour je suis en attente du programme de Basile";
	document.getElementById("output").element.value = '';
	}

function fonction_re() {	
	document.getElementById("output").innerHTML="texte traduit";
	document.getElementById("output").style.color = "grey";
	document.getElementById("input").style.color = "grey";
	document.getElementById("input").innerHTML="Entrer votre texte";
}