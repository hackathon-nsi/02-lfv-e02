emoji(document.body)

function emoji(element) {
	var dict = {
  		"princesse": "👸",
  		"prince": "🤴",
  		"passion": "❤🔥",
		"plus":"➕",
		"moins":"➖",
		"roi":"👑"
	};
	
	if (element.hasChildNodes()) {
		element.childNodes.forEach(emoji)
	} else if (element.nodeType === Text.TEXT_NODE) {
		for (mot in dict) {
			var regex = new RegExp('\\b' + mot + 's?\\b', 'gim')
			element.textContent = element.textContent.replace(regex, dict[mot])
		}
		
		
	}
}


	

	
