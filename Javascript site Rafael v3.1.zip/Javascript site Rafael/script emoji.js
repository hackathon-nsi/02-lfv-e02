
function supr() {
	document.getElementById("input").style.color = "black";
	document.getElementById("input").innerHTML=" ";
}
function fonction_trad(){
	document.getElementById("output").style.color = "black";
	document.getElementById("output").innerHTML="bonjour je suis en attente du programme de Basile";
}