
function supr() {
	document.getElementById("input").style.color = "black";
	var txt = document.getElementById("input").value;
	if (txt=="Entrer votre texte"){
	document.getElementById("input").value ="Le prince et la princesse font une dance.";
	}
}


function fonction_re() {	
	document.getElementById("output").innerHTML="texte traduit";
	document.getElementById("output").style.color = "grey";
	document.getElementById("input").style.color = "grey";
	document.getElementById("input").value="Entrer votre texte";
}



function emoji() {

	var txt = document.getElementById("input").value;
	var list = txt.split(' ');

	
	var final = '';
    var o = ''
	var dict = {
  		"princesse": "👸",
  		"prince": "🤴",
  		"passion": "❤🔥"
	};



	for (i=0 ; i<list.length ; i++) {
  		if (list[i] == "princesse"){
			o = dict["princesse"]
		}
		else if (list[i] == "princesses"){
			o = dict["princesse"]
        	}else if (list[i] == "princes"){
			o = dict["prince"]
        	}else if (list[i] == "prince"){
			o = dict["prince"]
        	}else if (list[i] == "passion"){
			o = dict["passion"]
		}else if (list[i] == "passions"){
			o = dict["passions"]		
		}else{
		o=list[i]}
		final = final +" "+ o
	}	
	document.getElementById("output").innerHTML = final;

	document.getElementById("output").style.color = "black";


}

