
function supr() {
	document.getElementById("input").style.color = "black";
	document.getElementById("input").value ="";
}


function fonction_re() {	
	document.getElementById("output").innerHTML="texte traduit";
	document.getElementById("output").style.color = "grey";
	document.getElementById("input").style.color = "grey";
	document.getElementById("input").value="Entrer votre texte";
}



function emoji() {
	document.getElementById("output").style.color = "black";
		var txt = document.getElementById("input").value;
		var list = txt.split(' ');
		var final = '';
	var o = ''
		var dict = {
			"princesse": "/U1f478",
			"prince": "/U1f934",
			"passion": "/U12764"
		};

		

		for (i=0 ; i<list.lenght ; i++) {
			if (list[i] == "princesse"){
				o = dict["princesse"]
			}else if (list[i] == "princesses"){
				o = dict["princesse"]
		}else if (list[i] == "princes"){
				o = dict["prince"]
		}else if (list[i] == "prince"){
				o = dict["prince"]
		}else if (list[i] == "passion"){
				o = dict["passion"]
		}else if (list[i] == "passions"){
				o = dict["passions"]
		}else{
				o=list[i]
		}
		final = final + o
		
	final = final+list[0]
	}	
		document.getElementById("output").innerHTML = final;

}



